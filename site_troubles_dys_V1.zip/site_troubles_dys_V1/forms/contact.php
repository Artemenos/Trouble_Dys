<?php

  // Remplacez contact@example.com par votre véritable adresse e-mail de réception
  $receiving_email_address = 'contact@example.com';

  // Vérifie si le fichier "PHP Email Form" existe et l'inclut
  if( file_exists($php_email_form = '../assets/vendor/php-email-form/php-email-form.php' )) {
    include( $php_email_form );
  } else {
    // Si le fichier n'existe pas, affiche un message d'erreur et termine l'exécution du script
    die('Impossible de charger la bibliothèque «PHP Email Form» !');
  }

  // Crée une nouvelle instance de la classe PHP_Email_Form
  $contact = new PHP_Email_Form;
  $contact->ajax = true; // Active l'envoi de formulaire via AJAX
  
  // Définit l'adresse e-mail de destination
  $contact->to = $receiving_email_address;
  // Récupère le nom de l'expéditeur à partir du formulaire POST
  $contact->from_name = $_POST['name'];
  // Récupère l'adresse e-mail de l'expéditeur à partir du formulaire POST
  $contact->from_email = $_POST['email'];
  // Récupère le sujet du message à partir du formulaire POST
  $contact->subject = $_POST['subject'];

  // Décommentez le code ci-dessous si vous souhaitez utiliser SMTP pour envoyer des e-mails. Vous devez entrer vos identifiants SMTP corrects
  /*
  $contact->smtp = array(
    'host' => 'example.com',     // Adresse du serveur SMTP
    'username' => 'example',     // Nom d'utilisateur SMTP
    'password' => 'pass',        // Mot de passe SMTP
    'port' => '587'              // Port SMTP
  );
  */

  // Ajoute les informations du formulaire au message
  $contact->add_message( $_POST['name'], 'From'); // Ajoute le nom de l'expéditeur
  $contact->add_message( $_POST['email'], 'Email'); // Ajoute l'e-mail de l'expéditeur
  $contact->add_message( $_POST['message'], 'Message', 10); // Ajoute le contenu du message

  // Envoie l'e-mail et affiche le résultat de l'envoi
  echo $contact->send();

?>
